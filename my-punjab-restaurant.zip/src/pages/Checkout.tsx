import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, Plus, Minus, ShoppingBag, CreditCard, Wallet, Banknote, AlertCircle, Lock } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Link } from 'react-router-dom';

export default function Checkout() {
  const { items, updateQuantity, removeItem, totalPrice, clearCart } = useCart();
  const [orderType, setOrderType] = useState<'takeout' | 'delivery' | 'dine-in'>('delivery');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'cash' | null>(null);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [cardDetails, setCardDetails] = useState({ number: '', expiry: '', cvc: '' });
  const [cardErrors, setCardErrors] = useState({ number: '', expiry: '', cvc: '' });
  const [orderNotes, setOrderNotes] = useState('');

  const deliveryFee = orderType === 'delivery' ? (totalPrice >= 50 ? 0 : 3.50) : 0;
  const amountForFreeDelivery = Math.max(0, 50 - totalPrice);
  const finalTotal = totalPrice + deliveryFee;

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    const formattedValue = value.replace(/(\d{4})/g, '$1 ').trim();
    setCardDetails(prev => ({ ...prev, number: formattedValue.substring(0, 19) }));
    setCardErrors(prev => ({ ...prev, number: '' }));
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 2) {
      value = `${value.substring(0, 2)}/${value.substring(2, 4)}`;
    }
    setCardDetails(prev => ({ ...prev, expiry: value }));
    setCardErrors(prev => ({ ...prev, expiry: '' }));
  };

  const handleCvcChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').substring(0, 4);
    setCardDetails(prev => ({ ...prev, cvc: value }));
    setCardErrors(prev => ({ ...prev, cvc: '' }));
  };

  const handleCheckout = () => {
    if (!paymentMethod) {
      setPaymentError('Please select a payment method to complete your order.');
      return;
    }

    if (paymentMethod === 'card') {
      let hasError = false;
      const newErrors = { number: '', expiry: '', cvc: '' };

      if (cardDetails.number.replace(/\s/g, '').length < 16) {
        newErrors.number = 'Please enter a valid 16-digit card number.';
        hasError = true;
      }
      if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(cardDetails.expiry)) {
        newErrors.expiry = 'Please enter a valid expiry date (MM/YY).';
        hasError = true;
      }
      if (cardDetails.cvc.length < 3) {
        newErrors.cvc = 'Please enter a valid CVC.';
        hasError = true;
      }

      setCardErrors(newErrors);
      if (hasError) return;
    }
    
    setPaymentError(null);
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      clearCart();
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="pt-32 pb-24 min-h-screen bg-background flex items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card p-12 rounded-3xl border border-border text-center max-w-lg w-full mx-4"
        >
          <div className="w-24 h-24 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.2 }}
            >
              <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </motion.div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-4">Order Confirmed!</h2>
          <p className="text-gray-400 mb-8">
            Your order has been received and is being prepared. 
            {orderType === 'delivery' ? ' It will be delivered soon.' : ' It will be ready for pickup shortly.'}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link 
              to="/order-tracking" 
              className="w-full sm:w-auto px-8 py-4 bg-primary text-white font-bold rounded-full uppercase tracking-wider hover:bg-primary/90 transition-colors"
            >
              Track Your Order
            </Link>
            <Link 
              to="/menu" 
              className="w-full sm:w-auto px-8 py-4 bg-transparent border border-accent text-accent font-bold rounded-full uppercase tracking-wider hover:bg-accent hover:text-black transition-colors"
            >
              Order Again
            </Link>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 min-h-screen bg-background">
      <div className="container mx-auto px-4 md:px-8 max-w-6xl">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-12">Checkout</h1>

        {items.length === 0 ? (
          <div className="text-center py-20 bg-card rounded-3xl border border-border">
            <ShoppingBag className="w-16 h-16 text-gray-500 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-white mb-4">Your cart is empty</h2>
            <p className="text-gray-400 mb-8">Looks like you haven't added any delicious food yet.</p>
            <Link 
              to="/menu" 
              className="inline-block px-8 py-4 bg-primary text-white font-bold rounded-full uppercase tracking-wider hover:bg-primary/90 transition-colors"
            >
              Browse Menu
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-card rounded-3xl border border-border p-6 md:p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Order Summary</h2>
                
                <div className="space-y-6">
                  <AnimatePresence>
                    {items.map(item => (
                      <motion.div 
                        key={item.id}
                        layout
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="flex flex-col sm:flex-row items-center gap-4 py-4 border-b border-border last:border-0"
                      >
                        <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-xl" referrerPolicy="no-referrer" />
                        <div className="flex-grow text-center sm:text-left">
                          <h3 className="text-lg font-bold text-white">{item.name}</h3>
                          <p className="text-accent font-bold">€{item.price.toFixed(2)}</p>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <div className="flex items-center bg-background rounded-full border border-border p-1">
                            <button 
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-8 text-center text-white font-bold">{item.quantity}</span>
                            <button 
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                          <button 
                            onClick={() => removeItem(item.id)}
                            className="p-2 text-gray-500 hover:text-primary transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>

              {/* Order Options */}
              <div className="bg-card rounded-3xl border border-border p-6 md:p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Order Options</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {(['delivery', 'takeout', 'dine-in'] as const).map((type) => (
                    <button
                      key={type}
                      onClick={() => setOrderType(type)}
                      className={`p-4 rounded-xl border-2 transition-all capitalize font-bold ${
                        orderType === type 
                          ? 'border-accent bg-accent/10 text-accent' 
                          : 'border-border bg-background text-gray-400 hover:border-gray-600'
                      }`}
                    >
                      {type.replace('-', ' ')}
                    </button>
                  ))}
                </div>
                
                {orderType === 'delivery' && (
                  <div className="mt-6 space-y-4">
                    <input type="text" placeholder="Full Name" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none" />
                    <input type="text" placeholder="Delivery Address" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none" />
                    <input type="text" placeholder="Phone Number" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none" />
                  </div>
                )}
              </div>

              {/* Special Instructions */}
              <div className="bg-card rounded-3xl border border-border p-6 md:p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Special Instructions</h2>
                <textarea 
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="Add any special requests, allergies, or delivery instructions here..." 
                  className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none min-h-[120px] resize-y"
                />
              </div>

              {/* Payment Method */}
              <div className="bg-card rounded-3xl border border-border p-6 md:p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Payment Method</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <button
                    onClick={() => { setPaymentMethod('card'); setPaymentError(null); }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      paymentMethod === 'card' 
                        ? 'border-accent bg-accent/10 text-accent' 
                        : 'border-border bg-background text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    <CreditCard className="w-6 h-6" />
                    <span className="font-bold">Credit Card</span>
                  </button>
                  <button
                    onClick={() => { setPaymentMethod('paypal'); setPaymentError(null); }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      paymentMethod === 'paypal' 
                        ? 'border-accent bg-accent/10 text-accent' 
                        : 'border-border bg-background text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    <Wallet className="w-6 h-6" />
                    <span className="font-bold">PayPal</span>
                  </button>
                  <button
                    onClick={() => { setPaymentMethod('cash'); setPaymentError(null); }}
                    className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
                      paymentMethod === 'cash' 
                        ? 'border-accent bg-accent/10 text-accent' 
                        : 'border-border bg-background text-gray-400 hover:border-gray-600'
                    }`}
                  >
                    <Banknote className="w-6 h-6" />
                    <span className="font-bold text-sm">Cash on Delivery</span>
                  </button>
                </div>

                {paymentMethod === 'card' && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }} 
                    animate={{ opacity: 1, height: 'auto' }} 
                    className="mt-6 space-y-4 overflow-hidden"
                  >
                    <div className="flex items-center gap-2 mb-2 text-green-500 bg-green-500/10 p-3 rounded-lg border border-green-500/20">
                      <Lock className="w-4 h-4" />
                      <span className="text-sm font-bold">Secure 256-bit SSL Encryption</span>
                    </div>
                    <div>
                      <input 
                        type="text" 
                        placeholder="Card Number" 
                        value={cardDetails.number}
                        onChange={handleCardNumberChange}
                        className={`w-full bg-background border rounded-xl p-4 text-white focus:outline-none ${cardErrors.number ? 'border-red-500 focus:border-red-500' : 'border-border focus:border-accent'}`} 
                      />
                      {cardErrors.number && <p className="text-red-500 text-xs mt-1 ml-2">{cardErrors.number}</p>}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <input 
                          type="text" 
                          placeholder="MM/YY" 
                          value={cardDetails.expiry}
                          onChange={handleExpiryChange}
                          className={`w-full bg-background border rounded-xl p-4 text-white focus:outline-none ${cardErrors.expiry ? 'border-red-500 focus:border-red-500' : 'border-border focus:border-accent'}`} 
                        />
                        {cardErrors.expiry && <p className="text-red-500 text-xs mt-1 ml-2">{cardErrors.expiry}</p>}
                      </div>
                      <div>
                        <input 
                          type="text" 
                          placeholder="CVC" 
                          value={cardDetails.cvc}
                          onChange={handleCvcChange}
                          className={`w-full bg-background border rounded-xl p-4 text-white focus:outline-none ${cardErrors.cvc ? 'border-red-500 focus:border-red-500' : 'border-border focus:border-accent'}`} 
                        />
                        {cardErrors.cvc && <p className="text-red-500 text-xs mt-1 ml-2">{cardErrors.cvc}</p>}
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Cross-Selling / Complete Your Meal */}
              <div className="bg-card rounded-3xl border border-border p-6 md:p-8">
                <h2 className="text-2xl font-bold text-white mb-6">Complete Your Meal</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { id: 's1', name: 'Garlic Naan', price: 3.50, image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=200&auto=format&fit=crop' },
                    { id: 's2', name: 'Mint Raita', price: 2.00, image: 'https://images.unsplash.com/photo-1570696516188-ade861b48a49?q=80&w=200&auto=format&fit=crop' }
                  ].map(side => (
                    <div key={side.id} className="flex items-center gap-4 bg-background p-3 rounded-xl border border-border hover:border-accent/50 transition-colors">
                      <img src={side.image} alt={side.name} className="w-16 h-16 object-cover rounded-lg" referrerPolicy="no-referrer" />
                      <div className="flex-1">
                        <h4 className="text-white font-bold text-sm">{side.name}</h4>
                        <p className="text-accent text-sm font-bold">€{side.price.toFixed(2)}</p>
                      </div>
                      <button 
                        onClick={() => {
                          const { addItem } = useCart();
                          addItem({ ...side, quantity: 1 });
                        }}
                        className="p-2 bg-primary/10 text-primary hover:bg-primary hover:text-white rounded-full transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Payment Summary */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-3xl border border-border p-6 md:p-8 sticky top-32">
                <h2 className="text-2xl font-bold text-white mb-6">Summary</h2>
                
                <div className="space-y-4 mb-8 text-gray-300">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>€{totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span>
                      {orderType === 'delivery' ? (
                        totalPrice >= 50 ? (
                          <span className="text-green-500 font-bold">Free</span>
                        ) : (
                          `€${deliveryFee.toFixed(2)}`
                        )
                      ) : (
                        '€0.00'
                      )}
                    </span>
                  </div>
                  {orderType === 'delivery' && totalPrice < 50 && (
                    <div className="text-xs text-accent mt-1 text-right">
                      Add €{amountForFreeDelivery.toFixed(2)} more for free delivery!
                    </div>
                  )}
                  <div className="h-px bg-border my-4"></div>
                  <div className="flex justify-between text-xl font-bold text-white">
                    <span>Total</span>
                    <span className="text-accent">€{finalTotal.toFixed(2)}</span>
                  </div>
                </div>

                {paymentError && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }} 
                    animate={{ opacity: 1, y: 0 }} 
                    className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-xl flex items-start text-red-500"
                  >
                    <AlertCircle className="w-5 h-5 mr-3 shrink-0 mt-0.5" />
                    <p className="text-sm font-bold">{paymentError}</p>
                  </motion.div>
                )}

                <button 
                  onClick={handleCheckout}
                  disabled={isProcessing}
                  className="w-full py-4 bg-accent text-black font-bold rounded-xl uppercase tracking-wider hover:bg-accent/90 transition-all flex items-center justify-center disabled:opacity-70"
                >
                  {isProcessing ? (
                    <span className="flex items-center">
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <CreditCard className="w-5 h-5 mr-2" /> Pay €{finalTotal.toFixed(2)}
                    </span>
                  )}
                </button>
                
                <p className="text-center text-xs text-gray-500 mt-4 flex items-center justify-center">
                  Secure checkout powered by Stripe
                </p>
              </div>
            </div>
            
          </div>
        )}
      </div>
    </div>
  );
}
