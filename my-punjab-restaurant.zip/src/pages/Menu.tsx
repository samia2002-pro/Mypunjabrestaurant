import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Plus, Star, Filter } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { cn } from '../lib/utils';

const categories = ['All', 'Punjabi Food', 'Mutton Dishes', 'Drinks', 'Desserts'];

const menuItems = [
  {
    id: '1',
    name: 'Authentic Biryani',
    description: 'Fragrant basmati rice cooked with tender meat and secret spices.',
    price: 14.50,
    rating: 4.8,
    category: 'Punjabi Food',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=800&auto=format&fit=crop',
    isHalal: true,
  },
  {
    id: '2',
    name: 'Mutton Korma',
    description: 'Slow-cooked mutton in a rich, creamy, and aromatic gravy.',
    price: 16.00,
    rating: 4.9,
    category: 'Mutton Dishes',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=800&auto=format&fit=crop',
    isHalal: true,
  },
  {
    id: '3',
    name: 'Chicken Tikka Masala',
    description: 'Grilled chicken chunks in a spiced curry sauce.',
    price: 13.50,
    rating: 4.7,
    category: 'Punjabi Food',
    image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=800&auto=format&fit=crop',
    isHalal: true,
  },
  {
    id: '4',
    name: 'Palak Paneer',
    description: 'Fresh spinach puree cooked with homemade cottage cheese.',
    price: 11.00,
    rating: 4.5,
    category: 'Punjabi Food',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=800&auto=format&fit=crop',
    isHalal: true,
  },
  {
    id: '5',
    name: 'Mango Lassi',
    description: 'Sweet and creamy yogurt drink blended with fresh mangoes.',
    price: 4.50,
    rating: 4.9,
    category: 'Drinks',
    image: 'https://images.unsplash.com/photo-1570696516188-ade861b48a49?q=80&w=800&auto=format&fit=crop',
    isHalal: true,
  },
  {
    id: '6',
    name: 'Gulab Jamun',
    description: 'Deep-fried milk dumplings soaked in rose-flavored sugar syrup.',
    price: 5.00,
    rating: 4.8,
    category: 'Desserts',
    image: 'https://images.unsplash.com/photo-1598514982205-f36b96d1e8d4?q=80&w=800&auto=format&fit=crop',
    isHalal: true,
  },
];

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const { addItem } = useCart();

  const filteredItems = menuItems.filter(item => {
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="pt-32 pb-24 min-h-screen bg-background">
      <div className="container mx-auto px-4 md:px-8">
        
        {/* Header & Search */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Our Menu</h1>
            <p className="text-gray-400">Discover the authentic flavors of Punjab.</p>
          </div>
          
          <div className="w-full md:w-auto flex items-center gap-4">
            <div className="relative w-full md:w-72">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input 
                type="text" 
                placeholder="Search dishes..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-card border border-border rounded-full py-3 pl-12 pr-4 text-white focus:outline-none focus:border-accent transition-colors"
              />
            </div>
            <button className="p-3 bg-card border border-border rounded-full text-white hover:text-accent hover:border-accent transition-colors">
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex overflow-x-auto pb-4 mb-8 gap-4 scrollbar-hide">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "px-6 py-2 rounded-full whitespace-nowrap transition-all font-medium text-sm",
                activeCategory === category 
                  ? "bg-accent text-black" 
                  : "bg-card text-gray-400 border border-border hover:border-accent/50 hover:text-white"
              )}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Menu Grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredItems.map(item => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                key={item.id}
                className="bg-card border border-border rounded-2xl overflow-hidden group hover:border-accent/50 transition-colors flex flex-col"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {item.isHalal && (
                    <div className="absolute top-4 left-4 bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider">
                      Halal
                    </div>
                  )}
                  <div className="absolute top-4 right-4 bg-background/80 backdrop-blur-sm text-white text-xs font-bold px-2 py-1 rounded flex items-center">
                    <Star className="w-3 h-3 text-accent fill-current mr-1" /> {item.rating}
                  </div>
                </div>
                
                <div className="p-6 flex flex-col flex-grow">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-white group-hover:text-accent transition-colors">{item.name}</h3>
                    <span className="text-accent font-bold text-lg">€{item.price.toFixed(2)}</span>
                  </div>
                  <p className="text-gray-400 text-sm mb-6 flex-grow">{item.description}</p>
                  
                  <button 
                    onClick={() => addItem(item)}
                    className="w-full py-3 bg-primary/10 border border-primary text-primary hover:bg-primary hover:text-white rounded-xl font-bold transition-all flex items-center justify-center group/btn"
                  >
                    <Plus className="w-5 h-5 mr-2 transform group-hover/btn:rotate-90 transition-transform" />
                    Add to Cart
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {filteredItems.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-400 text-lg">No dishes found matching your criteria.</p>
            <button 
              onClick={() => {setSearchQuery(''); setActiveCategory('All');}}
              className="mt-4 text-accent hover:underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
