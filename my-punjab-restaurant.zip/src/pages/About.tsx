import { motion } from 'motion/react';
import { MapPin, Clock, Phone, Mail } from 'lucide-react';

export default function About() {
  return (
    <div className="pt-32 pb-24 min-h-screen bg-background">
      <div className="container mx-auto px-4 md:px-8 max-w-6xl">
        
        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-32">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-accent text-sm font-bold tracking-widest uppercase mb-4">Our Heritage</h2>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight">
              The Soul of <br/><span className="text-accent">Punjab</span> in Barcelona
            </h1>
            <p className="text-gray-400 text-lg leading-relaxed mb-6">
              Founded with a passion for authentic flavors, MY PUNJAB brings the rich, vibrant culinary traditions of Pakistan and North India straight to the heart of Gràcia, Barcelona.
            </p>
            <p className="text-gray-400 text-lg leading-relaxed mb-8">
              Every dish tells a story of our heritage, prepared using age-old recipes, premium halal meats, and spices sourced directly from the subcontinent. We believe that food is not just sustenance, but a celebration of culture and community.
            </p>
            
            <div className="flex items-center gap-6">
              <div className="text-center">
                <span className="block text-4xl font-bold text-white mb-1">15+</span>
                <span className="text-accent text-sm uppercase tracking-wider">Years Exp.</span>
              </div>
              <div className="w-px h-12 bg-border"></div>
              <div className="text-center">
                <span className="block text-4xl font-bold text-white mb-1">100%</span>
                <span className="text-accent text-sm uppercase tracking-wider">Halal</span>
              </div>
              <div className="w-px h-12 bg-border"></div>
              <div className="text-center">
                <span className="block text-4xl font-bold text-white mb-1">50+</span>
                <span className="text-accent text-sm uppercase tracking-wider">Dishes</span>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden border border-border">
              <img 
                src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1000&auto=format&fit=crop" 
                alt="Chef preparing food" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-8 -left-8 w-48 h-48 rounded-2xl overflow-hidden border-4 border-background hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=500&auto=format&fit=crop" 
                alt="Spices" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: MapPin, title: "Location", desc: "Carrer de Sardenya, 403, 08025 Barcelona" },
            { icon: Clock, title: "Opening Hours", desc: "Mon-Sun: 12:00 PM - 11:30 PM" },
            { icon: Phone, title: "Reservations", desc: "+34 123 456 789" },
            { icon: Mail, title: "Contact", desc: "info@mypunjab.es" }
          ].map((item, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="bg-card p-8 rounded-3xl border border-border text-center hover:border-accent/50 transition-colors"
            >
              <div className="w-16 h-16 mx-auto bg-background rounded-full flex items-center justify-center mb-6 border border-border">
                <item.icon className="w-8 h-8 text-accent" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
              <p className="text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </div>

      </div>
    </div>
  );
}
