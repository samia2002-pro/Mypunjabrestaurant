import { motion } from 'motion/react';
import { Star, Clock, MapPin, ChevronRight, Phone, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  const featuredDishes = [
    {
      id: 1,
      name: 'Authentic Biryani',
      description: 'Fragrant basmati rice cooked with tender meat and secret spices.',
      price: '€14.50',
      image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?q=80&w=800&auto=format&fit=crop',
    },
    {
      id: 2,
      name: 'Mutton Korma',
      description: 'Slow-cooked mutton in a rich, creamy, and aromatic gravy.',
      price: '€16.00',
      image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=800&auto=format&fit=crop',
    },
    {
      id: 3,
      name: 'Chicken Tikka Masala',
      description: 'Grilled chicken chunks in a spiced curry sauce.',
      price: '€13.50',
      image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=800&auto=format&fit=crop',
    },
  ];

  const reviews = [
    {
      id: 1,
      name: 'Maria G.',
      rating: 5,
      text: 'Absolutely the best Pakistani food in Barcelona! The Biryani is out of this world.',
      avatar: 'https://i.pravatar.cc/150?img=1',
    },
    {
      id: 2,
      name: 'Carlos R.',
      rating: 5,
      text: 'Incredible flavors and great service. The Mutton Korma is highly recommended.',
      avatar: 'https://i.pravatar.cc/150?img=11',
    },
    {
      id: 3,
      name: 'Sarah L.',
      rating: 4,
      text: 'Very authentic taste. The ambiance is lovely and the staff is very welcoming.',
      avatar: 'https://i.pravatar.cc/150?img=5',
    },
  ];

  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1514326640560-7d063ef2aed5?q=80&w=2000&auto=format&fit=crop" 
            alt="Restaurant Interior" 
            className="w-full h-full object-cover opacity-40"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-background"></div>
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto mt-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
              A Taste of <span className="text-accent">Punjab</span> in Barcelona
            </h1>
            <p className="text-lg md:text-2xl text-gray-300 mb-10 font-light">
              Experience authentic Halal Pakistani cuisine crafted with passion, tradition, and premium ingredients.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link 
                to="/menu" 
                className="px-8 py-4 bg-primary text-white font-bold rounded-full uppercase tracking-wider hover:bg-primary/90 transition-all transform hover:scale-105 w-full sm:w-auto flex items-center justify-center"
              >
                Order Now <ChevronRight className="ml-2 w-5 h-5" />
              </Link>
              <Link 
                to="/about" 
                className="px-8 py-4 bg-transparent border border-accent text-accent font-bold rounded-full uppercase tracking-wider hover:bg-accent hover:text-black transition-all transform hover:scale-105 w-full sm:w-auto"
              >
                Our Story
              </Link>
            </div>
          </motion.div>

          {/* Highlights */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-sm text-gray-300 backdrop-blur-sm bg-black/30 p-6 rounded-2xl border border-white/10"
          >
            <div className="flex flex-col items-center">
              <div className="flex items-center text-accent mb-2">
                <Star className="w-5 h-5 fill-current" />
                <span className="ml-1 font-bold text-lg text-white">4.3</span>
              </div>
              <span>73 Reviews</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-accent font-bold text-lg mb-2">€10 - €20</span>
              <span>Affordable Premium</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center text-green-500 mb-2">
                <span className="w-3 h-3 rounded-full bg-green-500 animate-pulse mr-2"></span>
                <span className="font-bold text-lg">Open</span>
              </div>
              <span>Until 11:30 PM</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-accent font-bold text-lg mb-2">100%</span>
              <span>Halal Certified</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Dishes */}
      <section className="py-24 bg-background relative">
        <div className="container mx-auto px-4 md:px-8">
          <div className="text-center mb-16">
            <h2 className="text-accent text-sm font-bold tracking-widest uppercase mb-2">Signature Dishes</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white">Taste the Tradition</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredDishes.map((dish, index) => (
              <motion.div
                key={dish.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, duration: 0.6 }}
                className="group relative rounded-2xl overflow-hidden bg-card border border-border hover:border-accent/50 transition-colors"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img 
                    src={dish.image} 
                    alt={dish.name} 
                    className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="p-6 relative z-10">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="text-xl font-bold text-white group-hover:text-accent transition-colors">{dish.name}</h4>
                    <span className="text-accent font-bold">{dish.price}</span>
                  </div>
                  <p className="text-gray-400 text-sm mb-6">{dish.description}</p>
                  <Link 
                    to="/menu" 
                    className="inline-flex items-center text-sm font-bold text-white uppercase tracking-wider group-hover:text-accent transition-colors"
                  >
                    Order Now <ChevronRight className="w-4 h-4 ml-1 transform group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-24 bg-card relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-accent/50 to-transparent"></div>
        <div className="container mx-auto px-4 md:px-8">
          <div className="text-center mb-16">
            <h2 className="text-accent text-sm font-bold tracking-widest uppercase mb-2">Testimonials</h2>
            <h3 className="text-4xl md:text-5xl font-bold text-white">What Our Guests Say</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, duration: 0.5 }}
                className="bg-background p-8 rounded-2xl border border-border relative"
              >
                <div className="flex items-center mb-6">
                  <img src={review.avatar} alt={review.name} className="w-12 h-12 rounded-full mr-4" referrerPolicy="no-referrer" />
                  <div>
                    <h4 className="text-white font-bold">{review.name}</h4>
                    <div className="flex text-accent">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-400 italic">"{review.text}"</p>
                <div className="absolute top-6 right-6 text-6xl text-accent/10 font-serif">"</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-8 right-8 z-50 flex flex-col gap-4">
        <a href="https://wa.me/34123456789" target="_blank" rel="noopener noreferrer" className="w-14 h-14 bg-green-500 rounded-full flex items-center justify-center text-white shadow-lg shadow-green-500/30 hover:scale-110 transition-transform">
          <MessageCircle className="w-6 h-6" />
        </a>
        <a href="tel:+34123456789" className="w-14 h-14 bg-accent rounded-full flex items-center justify-center text-black shadow-lg shadow-accent/30 hover:scale-110 transition-transform">
          <Phone className="w-6 h-6" />
        </a>
      </div>
    </div>
  );
}
