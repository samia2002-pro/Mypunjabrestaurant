import { motion } from 'motion/react';
import { MapPin, Clock, CheckCircle2, ChefHat, Bike } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function OrderTracking() {
  return (
    <div className="pt-32 pb-24 min-h-screen bg-background">
      <div className="container mx-auto px-4 md:px-8 max-w-3xl">
        <div className="text-center mb-12">
          <h2 className="text-accent text-sm font-bold tracking-widest uppercase mb-2">Order #MP-8472</h2>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Track Your Order</h1>
          <p className="text-gray-400">Estimated delivery time: <span className="text-white font-bold">35-45 mins</span></p>
        </div>

        <div className="bg-card rounded-3xl border border-border p-8 md:p-12 relative overflow-hidden">
          {/* Progress Line */}
          <div className="absolute left-12 md:left-16 top-12 bottom-12 w-1 bg-border rounded-full">
            <motion.div 
              initial={{ height: 0 }}
              animate={{ height: '50%' }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
              className="w-full bg-accent rounded-full"
            ></motion.div>
          </div>

          <div className="space-y-12 relative z-10">
            {/* Step 1 */}
            <div className="flex items-start gap-6">
              <div className="w-10 h-10 rounded-full bg-accent text-black flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(212,175,55,0.5)]">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-1">Order Confirmed</h3>
                <p className="text-gray-400 text-sm">We have received your order and payment.</p>
                <span className="text-xs text-gray-500 mt-2 block">12:30 PM</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-start gap-6">
              <div className="w-10 h-10 rounded-full bg-accent text-black flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(212,175,55,0.5)]">
                <ChefHat className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-1">Preparing Your Food</h3>
                <p className="text-gray-400 text-sm">Our chefs are preparing your delicious meal.</p>
                <span className="text-xs text-gray-500 mt-2 block">12:35 PM</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-6">
              <div className="w-10 h-10 rounded-full bg-background border-2 border-border text-gray-500 flex items-center justify-center shrink-0">
                <Bike className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-500 mb-1">Out for Delivery</h3>
                <p className="text-gray-600 text-sm">Your order is on the way to your address.</p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-start gap-6">
              <div className="w-10 h-10 rounded-full bg-background border-2 border-border text-gray-500 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-gray-500 mb-1">Delivered</h3>
                <p className="text-gray-600 text-sm">Enjoy your meal!</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link 
            to="/" 
            className="inline-flex items-center text-gray-400 hover:text-white transition-colors"
          >
            Return to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
