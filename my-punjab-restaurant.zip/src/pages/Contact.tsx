import { motion } from 'motion/react';
import { MapPin, Phone, Mail, Send } from 'lucide-react';

export default function Contact() {
  return (
    <div className="pt-32 pb-24 min-h-screen bg-background">
      <div className="container mx-auto px-4 md:px-8 max-w-6xl">
        
        <div className="text-center mb-16">
          <h2 className="text-accent text-sm font-bold tracking-widest uppercase mb-2">Get in Touch</h2>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Contact Us</h1>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Whether you want to book a table, ask about our menu, or plan a special event, we're here to help.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-card p-8 md:p-12 rounded-3xl border border-border"
          >
            <h3 className="text-2xl font-bold text-white mb-8">Send us a Message</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">First Name</label>
                  <input type="text" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors" placeholder="John" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Last Name</label>
                  <input type="text" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors" placeholder="Doe" />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
                <input type="email" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors" placeholder="john@example.com" />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Message</label>
                <textarea rows={5} className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors resize-none" placeholder="How can we help you?"></textarea>
              </div>
              
              <button type="submit" className="w-full py-4 bg-accent text-black font-bold rounded-xl uppercase tracking-wider hover:bg-accent/90 transition-all flex items-center justify-center group">
                Send Message <Send className="w-5 h-5 ml-2 transform group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </button>
            </form>
          </motion.div>

          {/* Contact Info & Map */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-8"
          >
            <div className="bg-card p-8 rounded-3xl border border-border flex items-start space-x-6">
              <div className="w-14 h-14 bg-background rounded-full flex items-center justify-center shrink-0 border border-border">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-xl font-bold text-white mb-2">Visit Us</h4>
                <p className="text-gray-400 leading-relaxed">
                  Carrer de Sardenya, 403<br/>
                  08025 Barcelona, Spain<br/>
                  (Located in the vibrant Gràcia neighborhood)
                </p>
              </div>
            </div>

            <div className="bg-card p-8 rounded-3xl border border-border flex items-start space-x-6">
              <div className="w-14 h-14 bg-background rounded-full flex items-center justify-center shrink-0 border border-border">
                <Phone className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-xl font-bold text-white mb-2">Call Us</h4>
                <p className="text-gray-400 leading-relaxed">
                  +34 123 456 789<br/>
                  Available during opening hours for reservations and takeout orders.
                </p>
              </div>
            </div>

            <div className="bg-card p-8 rounded-3xl border border-border flex items-start space-x-6">
              <div className="w-14 h-14 bg-background rounded-full flex items-center justify-center shrink-0 border border-border">
                <Mail className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h4 className="text-xl font-bold text-white mb-2">Email Us</h4>
                <p className="text-gray-400 leading-relaxed">
                  info@mypunjab.es<br/>
                  For catering, events, or general inquiries.
                </p>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="aspect-video bg-card rounded-3xl border border-border overflow-hidden relative group">
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-10 opacity-0 group-hover:opacity-100 transition-opacity">
                <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer" className="px-6 py-3 bg-accent text-black font-bold rounded-full uppercase tracking-wider">
                  Open in Maps
                </a>
              </div>
              <img 
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=1000&auto=format&fit=crop" 
                alt="Map location" 
                className="w-full h-full object-cover opacity-50 grayscale"
                referrerPolicy="no-referrer"
              />
            </div>

          </motion.div>
        </div>

      </div>
    </div>
  );
}
