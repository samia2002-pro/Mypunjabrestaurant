import { motion } from 'motion/react';
import { Calendar, Users, Clock, CheckCircle } from 'lucide-react';
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Reservation() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="pt-32 pb-24 min-h-screen bg-background flex items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card p-12 rounded-3xl border border-border text-center max-w-lg w-full mx-4"
        >
          <div className="w-24 h-24 bg-accent/20 text-accent rounded-full flex items-center justify-center mx-auto mb-6">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 10, delay: 0.2 }}
            >
              <CheckCircle className="w-12 h-12" />
            </motion.div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-4">Table Requested!</h2>
          <p className="text-gray-400 mb-8">
            Thank you for choosing MY PUNJAB. We have received your reservation request and will send a confirmation email shortly.
          </p>
          <Link 
            to="/" 
            className="inline-block px-8 py-4 bg-accent text-black font-bold rounded-full uppercase tracking-wider hover:bg-accent/90 transition-colors"
          >
            Return Home
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 min-h-screen bg-background">
      <div className="container mx-auto px-4 md:px-8 max-w-4xl">
        
        <div className="text-center mb-16">
          <h2 className="text-accent text-sm font-bold tracking-widest uppercase mb-2">Book a Table</h2>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Reservations</h1>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Join us for an unforgettable dining experience. Reserve your table in advance to ensure availability.
          </p>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-card p-8 md:p-12 rounded-3xl border border-border"
        >
          <form className="space-y-8" onSubmit={handleSubmit}>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2 flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-accent" /> Date
                </label>
                <input required type="date" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors" />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2 flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-accent" /> Time
                </label>
                <select required className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors appearance-none">
                  <option value="">Select Time</option>
                  <option value="12:00">12:00 PM</option>
                  <option value="13:00">1:00 PM</option>
                  <option value="14:00">2:00 PM</option>
                  <option value="19:00">7:00 PM</option>
                  <option value="20:00">8:00 PM</option>
                  <option value="21:00">9:00 PM</option>
                  <option value="22:00">10:00 PM</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2 flex items-center">
                  <Users className="w-4 h-4 mr-2 text-accent" /> Guests
                </label>
                <select required className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors appearance-none">
                  <option value="">Select Guests</option>
                  <option value="1">1 Person</option>
                  <option value="2">2 People</option>
                  <option value="3">3 People</option>
                  <option value="4">4 People</option>
                  <option value="5">5 People</option>
                  <option value="6">6+ People</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Full Name</label>
                <input required type="text" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors" placeholder="John Doe" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">Email Address</label>
                <input required type="email" className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors" placeholder="john@example.com" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Special Requests (Optional)</label>
              <textarea rows={3} className="w-full bg-background border border-border rounded-xl p-4 text-white focus:border-accent focus:outline-none transition-colors resize-none" placeholder="Allergies, special occasions, etc."></textarea>
            </div>
            
            <button type="submit" className="w-full py-4 bg-accent text-black font-bold rounded-xl uppercase tracking-wider hover:bg-accent/90 transition-all flex items-center justify-center">
              Confirm Reservation
            </button>
          </form>
        </motion.div>

      </div>
    </div>
  );
}
