import { Link, Outlet, useLocation } from 'react-router-dom';
import { ShoppingCart, Menu as MenuIcon, X, MapPin, Phone, Clock, Globe } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { useCart } from '../context/CartContext';
import Chatbot from './Chatbot';

export default function Layout() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [language, setLanguage] = useState('EN');
  const location = useLocation();
  const { totalItems } = useCart();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Menu', path: '/menu' },
    { name: 'About', path: '/about' },
    { name: 'Reservation', path: '/reservation' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Promo & Info Top Bar */}
      <div className="hidden md:flex justify-between items-center px-8 py-2 bg-black/90 text-xs text-gray-400 border-b border-border z-50 relative">
        <div className="flex items-center space-x-6">
          <span className="flex items-center"><MapPin className="w-3 h-3 mr-2 text-accent" /> Carrer de Sardenya, 403, Barcelona</span>
          <span className="flex items-center"><Phone className="w-3 h-3 mr-2 text-accent" /> +34 123 456 789</span>
        </div>
        
        {/* Promo Message */}
        <div className="absolute left-1/2 transform -translate-x-1/2 text-accent font-bold tracking-wider animate-pulse">
          GET 15% OFF YOUR FIRST ONLINE ORDER!
        </div>

        <div className="flex items-center space-x-6">
          <span className="flex items-center text-green-500"><span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></span> Open Now</span>
          
          {/* Language Toggle */}
          <button 
            onClick={() => setLanguage(lang => lang === 'EN' ? 'ES' : 'EN')}
            className="flex items-center hover:text-white transition-colors"
          >
            <Globe className="w-3 h-3 mr-1" /> {language}
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <header
        className={cn(
          'fixed w-full z-40 transition-all duration-300 border-b border-transparent',
          isScrolled || isMobileMenuOpen ? 'bg-background/95 backdrop-blur-md border-border py-4' : 'bg-transparent py-6',
          'md:top-[33px] top-0'
        )}
      >
        <div className="container mx-auto px-4 md:px-8 flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 group">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl group-hover:scale-110 transition-transform">
              MP
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-wider text-white uppercase">MY PUNJAB</span>
              <span className="text-[10px] text-accent tracking-widest uppercase">Halal Pakistaní Restaurante</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={cn(
                  'text-sm font-medium uppercase tracking-wider transition-colors hover:text-accent relative group',
                  location.pathname === link.path ? 'text-accent' : 'text-gray-300'
                )}
              >
                {link.name}
                <span className={cn(
                  "absolute -bottom-2 left-0 w-full h-0.5 bg-accent transform origin-left transition-transform duration-300",
                  location.pathname === link.path ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100"
                )}></span>
              </Link>
            ))}
          </nav>

          <div className="flex items-center space-x-4">
            <Link to="/checkout" className="relative p-2 text-white hover:text-accent transition-colors">
              <ShoppingCart className="w-6 h-6" />
              {totalItems > 0 && (
                <span className="absolute top-0 right-0 w-4 h-4 bg-primary text-white text-[10px] font-bold flex items-center justify-center rounded-full">
                  {totalItems}
                </span>
              )}
            </Link>
            
            <Link to="/menu" className="hidden md:flex items-center justify-center px-6 py-2.5 bg-accent text-accent-foreground font-semibold rounded-full hover:bg-accent/90 transition-colors transform hover:scale-105 active:scale-95">
              Order Now
            </Link>

            <button
              className="md:hidden p-2 text-white"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-background/95 backdrop-blur-xl pt-24 px-6 flex flex-col"
          >
            <nav className="flex flex-col space-y-6 text-center mt-10">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={cn(
                    'text-2xl font-bold uppercase tracking-wider transition-colors',
                    location.pathname === link.path ? 'text-accent' : 'text-white'
                  )}
                >
                  {link.name}
                </Link>
              ))}
              <Link to="/menu" className="mt-8 px-8 py-4 bg-primary text-white font-bold rounded-full uppercase tracking-wider">
                Order Now
              </Link>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* AI Chatbot Widget */}
      <Chatbot />

      {/* Footer */}
      <footer className="bg-card border-t border-border pt-16 pb-8">
        <div className="container mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <Link to="/" className="flex items-center space-x-2 mb-6">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-2xl">
                  MP
                </div>
                <div className="flex flex-col">
                  <span className="text-2xl font-bold tracking-wider text-white uppercase">MY PUNJAB</span>
                  <span className="text-xs text-accent tracking-widest uppercase">Halal Pakistaní Restaurante</span>
                </div>
              </Link>
              <p className="text-gray-400 max-w-md leading-relaxed">
                Experience the authentic taste of Punjab in the heart of Barcelona. 
                Premium halal cuisine, crafted with passion and tradition.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold uppercase tracking-wider mb-6">Quick Links</h4>
              <ul className="space-y-4">
                {navLinks.map(link => (
                  <li key={link.name}>
                    <Link to={link.path} className="text-gray-400 hover:text-accent transition-colors">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold uppercase tracking-wider mb-6">Contact Us</h4>
              <ul className="space-y-4 text-gray-400">
                <li className="flex items-start">
                  <MapPin className="w-5 h-5 mr-3 text-accent shrink-0 mt-0.5" />
                  <span>Carrer de Sardenya, 403<br/>08025 Barcelona, Spain</span>
                </li>
                <li className="flex items-center">
                  <Phone className="w-5 h-5 mr-3 text-accent shrink-0" />
                  <span>+34 123 456 789</span>
                </li>
                <li className="flex items-center">
                  <Clock className="w-5 h-5 mr-3 text-accent shrink-0" />
                  <span>Mon-Sun: 12:00 PM - 11:30 PM</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
            <p>&copy; {new Date().getFullYear()} MY PUNJAB Restaurante. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <a href="#" className="hover:text-accent transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-accent transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
